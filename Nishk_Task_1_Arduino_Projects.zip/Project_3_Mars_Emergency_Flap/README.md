# Project 3 Mars Emergency Flap

This project demonstrates mars emergency flap using Arduino.