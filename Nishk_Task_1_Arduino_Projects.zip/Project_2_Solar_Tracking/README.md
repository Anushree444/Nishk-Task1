# Project 2 Solar Tracking

This project demonstrates solar tracking using Arduino.