# Project 1 Motion Detector

This project demonstrates motion detector using Arduino.